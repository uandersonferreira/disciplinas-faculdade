package br.com.uanderson.aula03jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula04JpaMapeamentoApplicationTests {

    @Test
    void contextLoads() {
    }

}
