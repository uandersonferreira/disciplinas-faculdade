package br.com.uanderson.aula03jpa.model.entity;
import jakarta.persistence.*;

import java.util.List;
import java.util.Objects;

@Entity
public class ItemVenda {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private int qtd;
    @OneToOne // Um itemVenda para um produto
    @JoinColumn(name = "produto_id")
    private Produto produto;
    /*
    @OneToOne -> Um itemVenda para um produto
    @JoinColumn(name = "produto_id") -> Define que o atributo "produto" será
    referencia pela coluna de nome "produto_id" na tabela item_venda
    e que será na classe ItemVenda que a chave estrangeira da ligação entre
    Produto x ItemVenda ou seja o elo mais forte ficará.
     */

    @ManyToOne //Muitos ItemVenda pertence a uma Venda
    @JoinColumn(name = "id_venda")
    private Venda venda;

    public ItemVenda(Long id, int qtd, Produto produto, Venda venda) {
        this.id = id;
        this.qtd = qtd;
        this.produto = produto;
        this.venda = venda;
    }

    public ItemVenda() {
    }

    public double total(){
        return produto.getValor() * qtd;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ItemVenda itemVenda = (ItemVenda) o;
        return qtd == itemVenda.qtd && Objects.equals(id, itemVenda.id) && Objects.equals(produto, itemVenda.produto) && Objects.equals(venda, itemVenda.venda);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, qtd, produto, venda);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getQtd() {
        return qtd;
    }

    public void setQtd(int qtd) {
        this.qtd = qtd;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    public Venda getVenda() {
        return venda;
    }

    public void setVenda(Venda venda) {
        this.venda = venda;
    }
}//class
