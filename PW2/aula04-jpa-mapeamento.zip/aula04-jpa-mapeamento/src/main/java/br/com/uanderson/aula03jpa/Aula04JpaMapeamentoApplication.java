package br.com.uanderson.aula03jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aula04JpaMapeamentoApplication {

    public static void main(String[] args) {
        SpringApplication.run(Aula04JpaMapeamentoApplication.class, args);

    }

}
/*
O @PersistenceContext é usado especificamente quando precisamos injetar um EntityManager.

@mappedBy - Faz referência ao atributo da associação mais fraca,
quando queremos implementar uma associação bidirecional.

PRODUTO x ITEMVENDA

um produto para um itemvenda e um item venda para um produto
- oneToOne
- ITEMVENDA proprietário:
	- Na propriedade da associação anota-se com @OneToOne
	- É responsável por manter a associação
	- Declara a coluna de Ligação @JoinColumn

Do  lado oposto(PRODUTO) ao proprietário usa-se:
	- Anotação @OneToOne
    - Com atributo mappedBy

ITEMVENDA  x VENDA

vários ITEMVENDA para uma venda e uma VENDA para muitos itemVenda
- manyToOne

- ITEMVENDA é o proprietário
    - @ManyToOne
    - @JoinColumn

- VENDA:
    - @OneToMany
    - @mappedBY

Hibernate: alter table item_venda add constraint FK8gx9ywjid5ol0tghn01vyxf68 foreign key (id_produto) references produto (id)
Hibernate: alter table item_venda add constraint FK87qej2cxtg9b3px8smmpaq8nq foreign key (id_venda) references venda (id)

*/