package br.com.uanderson.aula03jpa.model.entity;

import jakarta.persistence.*;

import java.io.Serializable;
import java.util.Objects;

@Entity
public class Produto implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String descricao;
    private Double valor;

    @OneToOne(mappedBy = "produto")
    private ItemVenda itemVenda;
    /*
    @OneToOne -> Um produto para um itemVenda
    mappedBy = "produto" -> faz referência ao atributo "produto"
    definido na classe ItemVenda.

     */

    public Produto(Long id, String descricao, Double valor, ItemVenda itemVenda) {
        this.id = id;
        this.descricao = descricao;
        this.valor = valor;
        this.itemVenda = itemVenda;
    }

    public Produto() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public ItemVenda getItemVenda() {
        return itemVenda;
    }

    public void setItemVenda(ItemVenda itemVenda) {
        this.itemVenda = itemVenda;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Produto produto = (Produto) o;
        return Objects.equals(id, produto.id) && Objects.equals(descricao, produto.descricao) && Objects.equals(valor, produto.valor) && Objects.equals(itemVenda, produto.itemVenda);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, descricao, valor, itemVenda);
    }

    @Override
    public String toString() {
        return "Produto{" +
                "id=" + id +
                ", descricao='" + descricao + '\'' +
                ", valor=" + valor +
                ", itemVenda=" + itemVenda +
                '}';
    }
}//class
