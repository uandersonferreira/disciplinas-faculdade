package br.com.uanderson.aula06jpaheranca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula06JpaHerancaApplicationTests {

    @Test
    void contextLoads() {
    }

}
