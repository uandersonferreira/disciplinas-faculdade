const socket = io()
console.log("Conectado ao servidor")